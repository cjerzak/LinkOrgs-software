
# stubs that get overridden via configure script
TBB_LIB <- ""
TBB_INC <- ""
