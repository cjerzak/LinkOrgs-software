
library(Rcpp)
library(RUnit)

sourceCpp(system.file("tests/cpp/truefalse_macros.cpp", package = "RcppParallel"))

