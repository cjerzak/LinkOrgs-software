# This file is part of the standard testthat setup for R packages.
# It is automatically run by R CMD check.
library(testthat)
library(LinkOrgs)

test_check("LinkOrgs")
